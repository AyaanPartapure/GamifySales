/* ============================================================
   DEALERVERSE — FX ENGINE
   Particles · count-up · confetti · toasts · xp/coin flight · tilt
   ============================================================ */
const DV_FX = (function(){

  /* ---------- ambient particles (canvas) ---------- */
  function particles(){
    const c = document.getElementById('dv-particles');
    if(!c) return;
    const ctx = c.getContext('2d');
    let w,h,pts=[];
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    function resize(){ w=c.width=innerWidth; h=c.height=innerHeight; }
    resize(); addEventListener('resize', resize);
    const N = Math.min(70, Math.floor(innerWidth/22));
    const colors = ['58,92,255','155,92,255','244,183,64'];
    for(let i=0;i<N;i++){
      pts.push({
        x:Math.random()*w, y:Math.random()*h,
        vx:(Math.random()-.5)*.25, vy:(Math.random()-.5)*.25,
        r:Math.random()*1.6+.4, c:colors[i%3], a:Math.random()*.5+.15
      });
    }
    function tick(){
      ctx.clearRect(0,0,w,h);
      pts.forEach(p=>{
        p.x+=p.vx; p.y+=p.vy;
        if(p.x<0)p.x=w; if(p.x>w)p.x=0; if(p.y<0)p.y=h; if(p.y>h)p.y=0;
        ctx.beginPath();
        ctx.fillStyle = `rgba(${p.c},${p.a})`;
        ctx.arc(p.x,p.y,p.r,0,7);
        ctx.fill();
      });
      if(!reduced) requestAnimationFrame(tick);
    }
    tick();
  }

  /* ---------- count up numbers ---------- */
  function countUp(el, to, opts={}){
    const dur = opts.duration || 1400;
    const decimals = opts.decimals || 0;
    const prefix = opts.prefix || '';
    const suffix = opts.suffix || '';
    const start = performance.now();
    const from = opts.from || 0;
    function ease(t){ return 1-Math.pow(1-t,3); }
    function frame(now){
      const p = Math.min(1, (now-start)/dur);
      const val = from + (to-from)*ease(p);
      el.textContent = prefix + val.toLocaleString('en-IN', {maximumFractionDigits:decimals, minimumFractionDigits:decimals}) + suffix;
      if(p<1) requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }
  function countUpAllInView(){
    const els = document.querySelectorAll('[data-countup]');
    const io = new IntersectionObserver((entries)=>{
      entries.forEach(en=>{
        if(en.isIntersecting){
          const el = en.target;
          const to = parseFloat(el.dataset.countup);
          countUp(el, to, {decimals:parseInt(el.dataset.decimals||0), prefix:el.dataset.prefix||'', suffix:el.dataset.suffix||''});
          io.unobserve(el);
        }
      });
    }, {threshold:.4});
    els.forEach(el=>io.observe(el));
  }

  /* ---------- scroll reveal ---------- */
  function reveal(){
    const els = document.querySelectorAll('.reveal');
    const io = new IntersectionObserver((entries)=>{
      entries.forEach(en=>{
        if(en.isIntersecting){ en.target.classList.add('in'); io.unobserve(en.target); }
      });
    }, {threshold:.15});
    els.forEach(el=>io.observe(el));
  }

  /* ---------- card tilt ---------- */
  function tilt(){
    document.querySelectorAll('.tilt').forEach(card=>{
      card.addEventListener('mousemove', e=>{
        const r = card.getBoundingClientRect();
        const x = (e.clientX - r.left)/r.width - .5;
        const y = (e.clientY - r.top)/r.height - .5;
        card.style.transform = `perspective(700px) rotateY(${x*8}deg) rotateX(${-y*8}deg) translateY(-4px)`;
      });
      card.addEventListener('mouseleave', ()=>{ card.style.transform = ''; });
    });
  }

  /* ---------- toast ---------- */
  function ensureToastHost(){
    let host = document.querySelector('.dv-toast');
    if(!host){ host = document.createElement('div'); host.className='dv-toast'; document.body.appendChild(host); }
    return host;
  }
  function toast(icon, title, sub){
    const host = ensureToastHost();
    const el = document.createElement('div');
    el.className = 'dv-toast-item';
    el.innerHTML = `<span class="ic">${icon}</span><div><b>${title}</b><span>${sub||''}</span></div>`;
    host.appendChild(el);
    setTimeout(()=>{ el.style.opacity='0'; el.style.transform='translateX(30px)'; el.style.transition='.4s'; setTimeout(()=>el.remove(),400); }, 3600);
  }

  /* ---------- confetti ---------- */
  function confetti(originEl){
    const layer = document.getElementById('dv-fx-layer') || (()=>{ const d=document.createElement('div'); d.id='dv-fx-layer'; document.body.appendChild(d); return d; })();
    const rect = originEl ? originEl.getBoundingClientRect() : {left:innerWidth/2, top:innerHeight/2, width:0, height:0};
    const cx = rect.left + rect.width/2, cy = rect.top + rect.height/2;
    const colors = ['#3A5CFF','#9B5CFF','#F4B740','#34D399','#FFD874'];
    for(let i=0;i<40;i++){
      const p = document.createElement('div');
      const size = 6+Math.random()*6;
      p.style.cssText = `position:fixed; left:${cx}px; top:${cy}px; width:${size}px; height:${size*.4}px; background:${colors[i%colors.length]}; border-radius:2px; z-index:999;`;
      layer.appendChild(p);
      const ang = Math.random()*Math.PI*2, dist = 80+Math.random()*160;
      const dx = Math.cos(ang)*dist, dy = Math.sin(ang)*dist - 60;
      p.animate([
        {transform:'translate(0,0) rotate(0deg)', opacity:1},
        {transform:`translate(${dx}px,${dy+220}px) rotate(${360+Math.random()*360}deg)`, opacity:0}
      ], {duration:1100+Math.random()*500, easing:'cubic-bezier(.22,1,.36,1)'}).onfinish = ()=>p.remove();
    }
  }

  /* ---------- flying +XP / +coin ---------- */
  function fly(originEl, targetSelector, label, cls){
    const layer = document.getElementById('dv-fx-layer') || (()=>{ const d=document.createElement('div'); d.id='dv-fx-layer'; document.body.appendChild(d); return d; })();
    const target = document.querySelector(targetSelector);
    const from = originEl ? originEl.getBoundingClientRect() : {left:innerWidth/2, top:innerHeight/2, width:0,height:0};
    const to = target ? target.getBoundingClientRect() : {left:innerWidth-60, top:20, width:0,height:0};
    const el = document.createElement('div');
    el.textContent = label;
    el.style.cssText = `position:fixed; left:${from.left+from.width/2}px; top:${from.top}px; z-index:999; font-family:'JetBrains Mono',monospace; font-weight:700; font-size:14px; color:${cls==='gold'?'#F4B740':'#6E8BFF'}; pointer-events:none;`;
    layer.appendChild(el);
    el.animate([
      {transform:'translate(0,0)', opacity:1},
      {transform:`translate(${to.left-from.left}px, ${to.top-from.top}px)`, opacity:.2}
    ], {duration:900, easing:'cubic-bezier(.4,0,.2,1)'}).onfinish = ()=>el.remove();
  }

  function init(){
    particles();
    countUpAllInView();
    reveal();
    tilt();
  }

  return {init, toast, confetti, fly, countUp};
})();

document.addEventListener('DOMContentLoaded', DV_FX.init);
