/* ============================================================
   DEALERVERSE — APP SHELL (sidebar + topbar), built once, reused
   on every internal page so nav stays perfectly in sync.
   ============================================================ */
(function(){
  const NAV = [
    {group:"Play"},
    {href:"dashboard.html",        icon:"🏁", label:"Dashboard",        key:"dashboard"},
    {href:"booking-journey.html",  icon:"🏎️", label:"Booking Journey",  key:"journey"},
    {href:"competition.html",      icon:"⚔️", label:"Sales Competition",key:"competition"},
    {href:"leaderboard.html",      icon:"🏆", label:"Leaderboard",      key:"leaderboard"},
    {href:"achievements.html",     icon:"🎖️", label:"Achievements",     key:"achievements"},
    {href:"rewards.html",          icon:"🎁", label:"Rewards Shop",     key:"rewards"},
    {group:"Work"},
    {href:"booking-details.html",  icon:"📋", label:"Booking #3241",    key:"booking-details"},
    {href:"department-sales.html", icon:"📈", label:"Sales Dept.",      key:"dept-sales"},
    {href:"department-finance.html",icon:"💠", label:"Finance Dept.",   key:"dept-finance"},
    {href:"analytics.html",        icon:"📊", label:"Analytics",        key:"analytics"},
    {group:"You"},
    {href:"profile.html",          icon:"👤", label:"My Profile",       key:"profile"},
    {href:"notifications.html",    icon:"🔔", label:"Notifications",    key:"notifications"},
    {href:"settings.html",         icon:"⚙️", label:"Settings",         key:"settings"},
    {group:"Control"},
    {href:"admin.html",            icon:"🛡️", label:"Admin Panel",      key:"admin"},
  ];

  function sidebarHTML(active){
    const items = NAV.map(n=>{
      if(n.group) return `<div class="dv-nav-label">${n.group}</div>`;
      const cls = n.key===active ? "active" : "";
      return `<a href="${n.href}" class="${cls}"><span class="ic">${n.icon}</span>${n.label}</a>`;
    }).join("");
    return `
    <aside class="dv-sidebar" id="dvSidebar">
      <a href="../index.html" class="dv-brand">
        <div class="mark">🚗</div>
        <div class="word">DealerVerse<small>DEALERSHIP OS · v2.4</small></div>
      </a>
      <nav class="dv-nav">${items}</nav>
      <div class="dv-sidebar-foot">
        <div class="dv-rankpill">
          <div class="av">RS</div>
          <div class="meta"><b>Rahul Sharma</b><span>LVL 14 · Sales · Rank #3</span></div>
        </div>
        <a href="../index.html" class="btn btn-ghost btn-sm btn-block">↩ Sign out</a>
      </div>
    </aside>`;
  }

  function topbarHTML(pageTitle){
    return `
    <header class="dv-topbar">
      <button class="dv-burger" id="dvBurger">☰</button>
      <div class="dv-search">🔍 <span>Search bookings, employees, VINs…</span></div>
      <div class="spacer"></div>
      <div class="dv-stat-pill xp">⚡ 8,420 XP</div>
      <div class="dv-stat-pill coin">🪙 2,150</div>
      <div class="dv-bell" id="dvBell">🔔<span class="dot"></span></div>
      <div class="dv-avatar">RS</div>
    </header>`;
  }

  window.DV_SHELL = {
    mount(active, pageTitle){
      const sb = document.getElementById('dvSidebarMount');
      const tb = document.getElementById('dvTopbarMount');
      if(sb) sb.outerHTML = sidebarHTML(active);
      if(tb) tb.outerHTML = topbarHTML(pageTitle);
      const burger = document.getElementById('dvBurger');
      const sidebar = document.getElementById('dvSidebar');
      if(burger && sidebar){
        burger.addEventListener('click', ()=> sidebar.classList.toggle('open'));
      }
      const bell = document.getElementById('dvBell');
      if(bell){
        bell.addEventListener('click', ()=>{ window.location.href = 'notifications.html'; });
      }
    }
  };
})();
