Reserved for real dealership imagery (vehicle photos, employee avatars,
brand marks). The demo build renders avatars, icons and illustrations with
inline SVG/emoji so it runs instantly with zero external image requests.
